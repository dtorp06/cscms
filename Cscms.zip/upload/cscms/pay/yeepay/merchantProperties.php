<?php
/*
 * @Description 易宝支付产品通用接口范例 
 * @V3.0
 * @Author rui.xin
 */
#	商户编号p1_MerId,以及密钥merchantKey 需要从易宝支付平台获得
$p1_MerId	= CS_Ybpay_ID;																										#
$merchantKey	= CS_Ybpay_Key;		
$logName	= CSPATH."pay/yeepay/YeePay_HTML.log";
?> 
