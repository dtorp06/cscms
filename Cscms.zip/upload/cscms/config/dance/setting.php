<?php

if (!defined('FCPATH')) exit('No permission resources');

/**
 * 版块配置、版权说明
 */

return array(
	'mid'			=> 20,           //版块ID ，开发者填写1
	'name'			=> '音乐',      //版块名称
	'author'		=> 'CSCMS官方', //开发者名称
	'version'		=> '2.3',       //版块版本号
	'description'   => '诠释音乐门户', //板块说明200字以内
);
