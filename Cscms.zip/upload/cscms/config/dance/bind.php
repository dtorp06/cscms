<?php if (!defined('FCPATH')) exit('No direct script access allowed');
return array (
  'cscms_2' => 1,
  'cscms_3' => 4,
);?>