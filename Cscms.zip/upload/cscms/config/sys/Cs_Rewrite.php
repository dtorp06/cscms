<?php if (!defined('FCPATH')) exit('No direct script access allowed');
return array (
  'dance' => 'music',
  'singer' => 'singer',
  'news' => 'news',
  'pic' => 'pic',
  'vod' => 'vod',
);?>