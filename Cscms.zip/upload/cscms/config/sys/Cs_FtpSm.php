<?php
define('FTP_Sm_Server','127.0.0.1');  //远程FTP服务器IP   
define('FTP_Sm_Port','21');  //远程FTP端口  
define('FTP_Sm_Name','admin');  //远程FTP帐号  
define('FTP_Sm_Pass','111111');  //远程FTP密码  
define('FTP_Sm_Ive',TRUE);  //是否使用被动模式