<?php
define('CS_Qn_Bk',''); //空间名称 
define('CS_Qn_Ak',''); //AK   
define('CS_Qn_Sk',''); //SK  
define('CS_Qn_Url',''); //自定义域名 
