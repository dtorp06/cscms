<?php
define('CS_Appmode',1);  //第三方登录方式，0为独立，1为官方 
define('CS_Appid','');  //官方Appid 
define('CS_Appkey','');  //官方Appkey 

define('CS_Qqmode',1);  //QQ登陆开关 
define('CS_Qqid','');  //QQ登陆id 
define('CS_Qqkey','');  //QQ登陆key 

define('CS_Wbmode',0);  //微博登陆开关  
define('CS_Wbid','');   //微博登陆id  
define('CS_Wbkey','');  //微博登陆key  

define('CS_Bdmode',0);  //百度登陆开关  
define('CS_Bdid','');   //百度登陆id  
define('CS_Bdkey','');  //百度登陆key  

define('CS_Rrmode',0);  //人人登陆开关  
define('CS_Rrid','');   //人人登陆id  
define('CS_Rrkey','');  //人人登陆key  

define('CS_Kxmode',0);  //开心登陆开关  
define('CS_Kxid','');   //开心登陆id  
define('CS_Kxkey','');  //开心登陆key  

define('CS_Dbmode',0);  //豆瓣登陆开关  
define('CS_Dbid','');   //豆瓣登陆id  
define('CS_Dbkey','');  //豆瓣登陆key 