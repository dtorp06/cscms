<?php if (!defined('FCPATH')) exit('No direct script access allowed');
return array (
  'hostname' => '127.0.0.1',
  'port' => 11211,
  'weight' => 1,
);?>