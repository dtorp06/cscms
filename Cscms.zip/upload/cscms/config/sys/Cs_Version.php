<?php
//程序版本
define("CS_YPTURL","http://app.chshcms.com/");
define("CS_Version","4.1.6");
define("CS_Charset","utf8");
define("CS_Uptime","20170620");