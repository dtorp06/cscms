<?php
define('Web_Name','cms多元化内容管理系统'); //站点名称  
define('Web_Url','www.cscms.com'); //站点域名  
define('Web_Path','/'); //站点路径  
define('Admin_Code','111');  //后台验证码  
define('Web_Off',1);  //网站开关  
define('Web_Onneir','网站升级中...');  //网站关闭内容  
define('Web_Mode',1);  //网站运行模式  
define('Html_Index','index.html');  //主页静态URL  
define('Html_StopTime',1);  //生成间隔秒数  
define('Html_PageNum',30);  //每页生成数量  
define('Html_Wap_Dir','wap');  //手机版本目录  
define('Web_Icp','沪ICP备06000000号');  //网站ICP  
define('Admin_QQ','2811358863');  //站长QQ  
define('Admin_Tel','1300000000');  //站长电话  
define('Admin_Mail','chshcms@qq.com');  //站长EMAIL  
define('Web_Key','Dj小波|DJ黄子浩|Dj罗清|DJ文杰|DJ千里|Mc洋哥');  //热门搜索  
define('Web_Count','统计代码');  //统计代码  
define('Web_Title','程氏CMS'); //SEO-标题  
define('Web_Keywords','程氏CMS,cscms,cscmsv4'); //SEO-Keywords  
define('Web_Description','cms多元化内容管理系统'); //SEO-description  
define('Web_Notice','网站公告');  //网站公告  
define('Pl_Modes',0);  //评论方式  
define('Pl_Youke',0);  //游客是否可以评论  
define('Pl_Num',10);  //评论每页条数  
define('Pl_Yy_Name','');  //友言 ID  
define('Pl_Ds_Name','');  //多说账号  
define('Pl_Cy_Id','');  //畅言APP_Id  
define('Pl_Str','她妈,它妈,他妈,你妈,去死,贱人');  //评论过滤字符  
define('Cache_Is',0);  //缓存开关  
define('Cache_Mx','file');  //缓存适配器  
define('Cache_Time',7200);  //缓存时间  
define('CS_Play_w',293);    
define('CS_Play_h',56);    
define('CS_Play_sw',978);    
define('CS_Play_sh',480);    
define('CS_Play_AdloadTime',5); //视频播放前广告时间    
define('CS_Language','zh_cn'); //网站语言,english英文，zh_cn中文 
define('Mobile_Is',1);    //手机门户是否开启    
define('Mobile_Url','');  //手机门户域名    
define('Mobile_Win',1);   //电脑是否可以访问手机页面  
define('Mobile_Skins_Dir','default/html/');   //手机默认模版  
define('Mobile_User_Dir','default/html/');   //手机会员模版  
define('Mobile_Home_Dir','skin01/html/');   //手机空间模版  
define('Pc_Skins_Dir','default/html/');   //PC系统默认模版  
define('Pc_User_Dir','default/html/');   //PC会员默认模版  
define('Pc_Home_Dir','skin01/html/');   //PC空间默认模版  
define('Is_Ssl',0);   //是否开启SSL  