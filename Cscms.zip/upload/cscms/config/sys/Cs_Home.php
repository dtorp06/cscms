<?php
define('Home_Mode',0);  //会员伪静态开关    
define('Home_Ym',0); //二级域名开关  
define('Home_Fs',1);  //会员主页地址方式，1为会员名，2为会员ID   
define('Home_Hits',1); //是否开启防刷机制    
define('Home_YmUrl','cscms.com');  //泛域名地址   
define('Home_Ymext','www|user|home|dance|i|vod|pic|singer|news');  //泛域名保留地址