<?php
define('CS_WaterMark',0);  //水印开关  
define('CS_WaterMode',2);  //水印类型  
define('CS_WaterFontSize',14);  //水印字体大小  
define('CS_WaterLocation',3);  //水印位置  
define('CS_WaterFont','chshcms.com');  //水印文字  
define('CS_WaterFontColor','#3399FF');  //水印颜色  
define('CS_WaterLogo','attachment/logo.png');  //水印图片路径  
define('CS_WaterLogotm','90');  //水印质量  
define('CS_WaterLocations','2');  //LOGO图片坐标位置 
