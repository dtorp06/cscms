<?php
define('CS_Upy_Name',''); //又拍云授权账号  
define('CS_Upy_Pwd',''); //又拍云授权密码   
define('CS_Upy_Bucket',''); //又拍云空间名 
define('CS_Upy_Url',''); //又拍云访问域名