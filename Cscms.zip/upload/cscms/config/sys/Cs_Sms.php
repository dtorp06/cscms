<?php
define('CS_Sms_ID','');  //商户ID      
define('CS_Sms_Key','');  //商户KEY      
define('CS_Sms_Name','CSCMS');  //短信签名    