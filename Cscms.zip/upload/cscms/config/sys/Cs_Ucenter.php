<?php
define('UC_CONNECT', 'mysql');
define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'root');
define('UC_DBPW', 'root');
define('UC_DBNAME', 'bbs');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', '`bbs`.pre_ucenter_');
define('UC_KEY', 'cscmsv4');
define('UC_API', 'http://v35.cscms.com/bbs/uc_server/');
define('UC_CHARSET', 'utf-8');
define('UC_IP', '');
define('UC_APPID', 2);