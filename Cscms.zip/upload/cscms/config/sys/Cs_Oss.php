<?php
define('CS_Os_Bk',''); //BK  
define('CS_Os_Ai',''); //AI   
define('CS_Os_Ak',''); //AK  
