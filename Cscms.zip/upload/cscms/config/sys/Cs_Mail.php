<?php
define('CS_Smtpmode',0);      //SMTP开关     
define('CS_Smtphost','smtp.163.com');      //SMTP服务器      
define('CS_Smtpport','25');      //SMTP端口    
define('CS_Smtpuser','cscms');      //SMTP帐号     
define('CS_Smtppass','cscms');      //SMTP密码     
define('CS_Smtpmail','cscms@163.com');      //发送EMAIL     
define('CS_Smtpname','cscms');      //发送者名称