<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * @Cscms 4.x open source management system
 * @copyright 2009-2015 chshcms.com. All rights reserved.
 * @Author:Cheng Jie
 * @Dtime:2014-09-19
 */

if (is_file(CSCMS.PLUBPATH.FGF.'rewrite.php')) require CSCMS.PLUBPATH.FGF.'rewrite.php';
/**
 * 自定义路由
 */
 
//$route['自定义路由正则规则']	= '指向的路由URI（URI规则：控制器/方法/参数1的值/参数2的值...）';


