<?php

if (!defined('CSCMSPATH')) exit('No permission resources');

/**
 * 版块配置、版权说明
 */

return array(
	'mid'			=> 23,           //版块ID ，开发者填写1
	'name'			=> '歌手',      //版块名称
	'author'		=> 'CSCMS官方', //开发者名称
	'version'		=> '1.2',       //版块版本号
	'description'   => 'CSCMS歌手板块', //板块说明200字以内
);
