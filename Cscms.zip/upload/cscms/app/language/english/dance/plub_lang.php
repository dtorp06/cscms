<?php
//index
$lang['dance_01']	= "您访问的页面不存在~!";
$lang['dance_02']	= "提醒您";
$lang['dance_03']	= "ID为空";
$lang['dance_04']	= "您还没有登录";
$lang['dance_05']	= "数据不存在";
$lang['dance_06']	= "抱歉，您已经收藏过了";
$lang['dance_07']	= "收藏了歌曲";
$lang['dance_08']	= "您今天已经赞过了";
$lang['dance_09']	= "出错了，ID不能为空！";
$lang['dance_10']	= "出错了，该数据不存在或者没有审核！";
$lang['dance_11']	= "未加入";
$lang['dance_12']	= "出错了，该歌曲文件不存在！";
$lang['dance_13']	= "抱歉，您所在的会员组不能下载该歌曲，请先升级！";
$lang['dance_14']	= "抱歉，您等级不够，不能下载该歌曲！";
$lang['dance_15']	= "这首歌曲下载需要%s个金币，您的当前金币不够，请先充值！";
$lang['dance_16']	= "下载歌曲";
$lang['dance_17']	= "歌曲《%s》 - 下载分成";
$lang['dance_18']	= "出错了，该分类不存在！";
$lang['dance_19']	= "出错了，模板标示为空！";
$lang['dance_20']	= "没有了";
$lang['dance_21']	= "抱歉，歌曲收藏失败!";
$lang['dance_22']	= "歌曲专辑";
$lang['dance_23']	= "出错了，该专辑不存在！";
$lang['dance_24']	= "收藏了专辑";
$lang['dance_25']	= "该歌曲没有Lrc歌词";


