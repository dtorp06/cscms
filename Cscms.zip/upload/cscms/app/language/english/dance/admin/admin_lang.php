<?php
//控制器
$lang['plub_01']	= "";

//视图
$lang['tpl_01'] = "";