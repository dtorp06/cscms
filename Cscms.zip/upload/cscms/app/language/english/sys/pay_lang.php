<?php
$Lang['pay_01']='illegally hand in~!';
$Lang['pay_02']='illegal order~!';
$Lang['pay_03']='member\'s(%s) on-line Chong be worth';
$Lang['pay_04']='confirm';
$Lang['pay_05']='user\'s name:';
$Lang['pay_06']=' order:';
$Lang['pay_07']='congratulate you, Chong value success, please keep firmly in mind your order:';
$Lang['pay_08']='trade status:';
$Lang['pay_09']='sorry, trade failure~!';
$Lang['pay_10']='you have already paid success, please wait for station-master hair goods, please keep firmly in mind your order:';
$Lang['pay_11']='the on-line Chong value succeed notify';
$Lang['pay_12']='congratulate you, you the use just paid treasure success Chong value%s dollar, order:%S appreciates your support~~';
$Lang['pay_13']='the on-line payment notify';
$Lang['pay_14']='respect of member, how are you!You have already paid%s dollar, your bargain order%s, please wait for station-master hair goods, appreciate your support~~';
$Lang['pay_15']='the on-line hair goods notify';
$Lang['pay_16']='respect of member, how are you!Your bargain order%s, have already delivered goods~, appreciate your support~~';
$Lang['pay_17']='congratulate you, you already successful Chong value%s dollar, order:%S appreciates your support~~';
$Lang['pay_18']='sorry, this station temporarily nonsupport quick money pay~!';
$Lang['pay_19']='the order pay success, please wait for station-master hair goods~!';

