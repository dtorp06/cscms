<?php
//控制器
$lang['plub_01']	= '请选择要删除的数据~!';

//视图
$lang['tpl_01']	 = '位置';
$lang['tpl_02']	 = '会员';
$lang['tpl_03']	 = '分享记录';
$lang['tpl_04']	 = '用户名';
$lang['tpl_05']	 = '用户ID';
$lang['tpl_06']	 = '查询';
$lang['tpl_07']	 = '选';
$lang['tpl_08']	 = '分享会员';
$lang['tpl_09']	 = '奖励情况';
$lang['tpl_10']	 = '访问时间';
$lang['tpl_11']	 = '访问IP';
$lang['tpl_12']	 = '地理位置';
$lang['tpl_13']	 = '客户端详情';
$lang['tpl_14']	 = '没有找到相关记录';
$lang['tpl_15']	 = '金币:%s,经验:%s';
$lang['tpl_16']	 = '全选/反选';
$lang['tpl_17']	 = '删除选中';