<?php
//控制器
$lang['plub_01']	= '参数错误!';
$lang['plub_02']	= '数据不完整!';
$lang['plub_03']	= '请选择要删除的数据!';

//视图 gbook.html
$lang['tpl_01']	 = '位置';
$lang['tpl_02']	 = '会员';
$lang['tpl_03']	 = '留言管理';
$lang['tpl_04']	 = '用户名';
$lang['tpl_05']	 = '会员ID';
$lang['tpl_06']	 = '全部类型';
$lang['tpl_07']	 = '网站留言';
$lang['tpl_08']	 = '会员留言';
$lang['tpl_09']	 = '查询';
$lang['tpl_10']	 = '选';
$lang['tpl_11']	 = '接收人';
$lang['tpl_12']	 = '留言人';
$lang['tpl_13']	 = '类型';
$lang['tpl_14']	 = '留言内容';
$lang['tpl_15']	 = '时间';
$lang['tpl_16']	 = '操作';
$lang['tpl_17']	 = '没有找到相关记录';
$lang['tpl_18']	 = '系统';
$lang['tpl_19']	 = '游客';
$lang['tpl_20']	 = '（回复 ID:%s 的留言）';
$lang['tpl_21']	 = '删除';
$lang['tpl_22']	 = '回复留言';
$lang['tpl_23']	 = '回复';
$lang['tpl_24']	 = '未知';
$lang['tpl_25']	 = '会员';
$lang['tpl_26']	 = '网站';
$lang['tpl_27']	 = '全选/反选';
$lang['tpl_28']	 = '删除选中';
//gbook_hf.html
$lang['tpl_gh_01']	 = '回复内容';
$lang['tpl_gh_02']	 = '请输入回复内容';
$lang['tpl_gh_03']	 = '提交';
$lang['tpl_gh_04']	 = '重置';


