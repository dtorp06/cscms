<?php
//控制器
$lang['plub_01']	= '数据不完整!';
$lang['plub_02']	= '数据记录不存在!';
$lang['plub_03']	= '系统';
$lang['plub_04']	= '未知UID';
$lang['plub_05']	= '未读';
$lang['plub_06']	= '已读';
$lang['plub_07']	= '请选择要删除的数据';

//视图
$lang['tpl_01']	 = '位置';
$lang['tpl_02']	 = '会员';
$lang['tpl_03']	 = '私信管理';
$lang['tpl_04']	 = '标题';
$lang['tpl_05']	 = '用户名';
$lang['tpl_06']	 = '会员ID';
$lang['tpl_07']	 = '查询';
$lang['tpl_08']	 = '选';
$lang['tpl_09']	 = '收信人';
$lang['tpl_10']	 = '发信人';
$lang['tpl_11']	 = '标题';
$lang['tpl_12']	 = '状态';
$lang['tpl_13']	 = '时间';
$lang['tpl_14']	 = '操作';
$lang['tpl_15']	 = '没有找到相关记录!';
$lang['tpl_16']	 = '系统';
$lang['tpl_17']	 = '未知UID:';
$lang['tpl_18']	 = '未读';
$lang['tpl_19']	 = '已读';
$lang['tpl_20']	 = '私信详情';
$lang['tpl_21']	 = '查看';
$lang['tpl_22']	 = '删除';
$lang['tpl_23']	 = '全选/反选';
$lang['tpl_24']	 = '删除选中';

//msg_look.html
$lang['tpl_ml_01']	= '收信人：';
$lang['tpl_ml_02']	= '发信人：';
$lang['tpl_ml_03']	= '状态：';
$lang['tpl_ml_04']	= '标题：';
$lang['tpl_ml_05']	= '内容：';
$lang['tpl_ml_06']	= '时间：';