<?php
//控制器
$lang['plub_01']	= '<font color=red>参数错误，路径非法！</font>';
$lang['plub_02']	= '参数错误，路径为空！';
$lang['plub_03']	= '恭喜您，删除成功~!';
$lang['plub_04']	= '文件格式不支持！';
$lang['plub_05']	= '图片格式不正确~!';
$lang['plub_06']	= '超过php.ini允许的大小。';
$lang['plub_07']	= '超过表单允许的大小。';
$lang['plub_08']	= '文件只有部分被上传。';
$lang['plub_09']	= '请选择文件。';
$lang['plub_10']	= '找不到临时目录。';
$lang['plub_11']	= '写文件到硬盘出错。';
$lang['plub_12']	= '未知错误。';
$lang['plub_13']	= '目录名不正确。';
$lang['plub_14']    = '上传失败。';
$lang['plub_15']    = '不支持该文件格式';
$lang['plub_16']    = '不是合法的图片文件';
$lang['plub_17']    = '上传的文件超过了 php.ini 中 upload_max_filesize 选项限制的值';
$lang['plub_18']    = '上传文件的大小超过了 HTML 表单中 MAX_FILE_SIZE 选项指定的值';
$lang['plub_19']    = '文件只有部分被上传';
$lang['plub_20']    = '没有文件被上传';
$lang['plub_21']    = '找不到上传的临时文件夹';
$lang['plub_22']    = '文件写入失败';
$lang['plub_23']    = '发生异常错误，上传失败';
$lang['plub_24']    = '恭喜你，上传成功';
$lang['plub_25']    = '上传文件，保存失败';

//view--upload_dir.html
$lang['tpl_01']	 = '位置';
$lang['tpl_02']	 = '系统';
$lang['tpl_03']	 = '附件管理';
$lang['tpl_04']	 = '目录';
$lang['tpl_05']	 = '日期';
$lang['tpl_06']	 = '文件大小';
$lang['tpl_07']	 = '操作';
$lang['tpl_08']	 = '返回上一级';
$lang['tpl_09']	 = '打开';
$lang['tpl_10']	 = '删除';
$lang['tpl_11']	 = '查看';
$lang['tpl_12']	 = '当前目录：';

//view--upload.html
$lang['tpl_u_01']	 = '上传失败';
$lang['tpl_u_02']	 = '上传文件';
$lang['tpl_u_03']	 = '手动输入';
$lang['tpl_u_04']	 = '网站附件';
$lang['tpl_u_05']	 = '开始上传';
$lang['tpl_u_06']	 = '最多上传 <font color="red">%s</font> 个文件,单文件最大 <font color="red">%s</font> MB';
$lang['tpl_u_07']	 = '文件格式：';
$lang['tpl_u_08']	 = '图片链接:';