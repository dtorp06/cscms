<?php

//login
$lang['log_0']	= '用户名、密码、认证码不能为空！';
$lang['log_1']	= '抱歉，认证码不正确！';
$lang['log_2']	= '抱歉，密码不正确';
$lang['log_3']	= '抱歉，账号不存在！';

$lang['card_0']	= '抱歉，口令不能为空~!';
$lang['card_1']	= '口令验证成功';
$lang['card_2']	= '口令不正确！~';
$lang['card_3'] = '恭喜您，登录成功';

//login.html
$lang['login_01']	= '请输入用户名';
$lang['login_02']	= '请输入密码';
$lang['login_03']	= '请输入后台验证码';
$lang['login_04']	= '立即登录';
$lang['login_05']	= '取消重置';
//login_card.html
$lang['lcard_01']	= '口令卡验证';
$lang['lcard_02']	= '请输入口令卡上的 <span style="color: red;font-weight: bold;">%s</span> 坐标的数字';
$lang['lcard_03']	= '请输入口令';
$lang['lcard_04']	= '提交验证';
$lang['lcard_05']	= '取消重置';