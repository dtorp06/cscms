<?php
//控制器
$lang['plub_01']	= '参数错误，请重试~!';
$lang['plub_02']	= '抱歉，补丁地址错误~!';
$lang['plub_03']	= '对不起，您的服务器不支持远程下载~!';
$lang['plub_04']	= '抱歉，目录（./attachment/other/）没有写入权限！';
$lang['plub_05']	= '抱歉，补丁下载失败~!';
$lang['plub_06']	= '抱歉，当前版本不能使用~!';
$lang['plub_07']	= '抱歉，补丁下载失败~!';
$lang['plub_08']	= '抱歉，补丁解压失败~!';
$lang['plub_09']	= '抱歉，以上文件复制失败，请检查目录权限!';
$lang['plub_10']	= '返回上一页~';
$lang['plub_11']	= '恭喜您，在线升级完成。';
$lang['plub_12']	= '文件路径不能为空~!';
$lang['plub_13']	= '文件不存在~!';
$lang['plub_14']	= '重要文件，不允许在线查看！';
$lang['plub_15']	= '开始校验文件，请稍候...';
$lang['plub_16']	= '补丁说明.txt';
$lang['plub_17']	= '复制';
$lang['plub_18']	= '到';
$lang['plub_19']	= '失败';

//view - upgrade.html
$lang['tpl__0']	 = '位置';
$lang['tpl_00']	 = '系统';
$lang['tpl_01']	 = '系统升级';
$lang['tpl_02']	 = '版本名称';
$lang['tpl_03']	 = '版本号';
$lang['tpl_04']	 = '发行时间';
$lang['tpl_05']	 = '文件大小';
$lang['tpl_06']	 = '在线更新';
$lang['tpl_07']	 = '下载更新';
$lang['tpl_08']	 = '更新说明';
$lang['tpl_09']	 = '暂无数据记录';
$lang['tpl_10']	 = '（当前版本）';
$lang['tpl_11']	 = '请务必在更新前备份站点数据';
$lang['tpl_12']	 = '点击查看说明';
$lang['tpl_13']	 = '查看';

//view -- upgrade-md5.html
$lang['tpl_m_01']	 = '位置';
$lang['tpl_m_02']	 = '系统';
$lang['tpl_m_03']	 = '文件校验';
$lang['tpl_m_04']	 = '注意：文件校验为根目录下所有文件以及 <font class="colord">cscms</font>、<font class="colord">packs</font>、二个文件夹下所有目录和文件与默认程序同名文件md5值对比的结果，如果异常请用木马扫描工具扫描该文件是否包含木马。';
$lang['tpl_m_05']	 = '被修改文件';
$lang['tpl_m_06']	 = '丢失文件';
$lang['tpl_m_07']	 = '未知文件';
$lang['tpl_m_08']	 = '修改过的文件';
$lang['tpl_m_09']	 = '最后修改时间';
$lang['tpl_m_10']	 = '文件大小';
$lang['tpl_m_11']	 = '操作';
$lang['tpl_m_12']	 = '查看代码';
$lang['tpl_m_13']	 = '查看';
$lang['tpl_m_14']	 = '访问';
$lang['tpl_m_15']	 = '丢失文件';

//view -- upgrade-tips.html
$lang['tpl_t_01']	 = '文件校验中,请稍后...';