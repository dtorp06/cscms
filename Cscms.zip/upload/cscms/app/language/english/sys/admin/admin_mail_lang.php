<?php
//控制器
$lang['plub_01']	= 'SMTP服务器、账号、密码、发送Email不能留空~!';
$lang['plub_02']	= '抱歉，写入文件失败';
$lang['plub_03']	= '邮件标题和内容不能为空';
$lang['plub_04']	= '接收邮箱不能为空';
$lang['plub_05']	= '发送成功';
$lang['plub_06']	= '发送失败';
$lang['plub_07']	= '恭喜您，邮件全部发送完成';

//视图 全局
$lang['tpl_01']	 = '位置';
$lang['tpl_02']	 = '系统';
$lang['tpl_03']	 = '发送邮件配置';
$lang['tpl_04']	 = '邮件配置';
$lang['tpl_05']	 = '发送邮件';

//mail_setting.html
$lang['tpl_ms_01']	 = '发送邮件配置';
$lang['tpl_ms_02']	 = '发送邮件开关';
$lang['tpl_ms_03']	 = '开启';
$lang['tpl_ms_04']	 = '关闭';
$lang['tpl_ms_05']	 = 'SMTP服务器';
$lang['tpl_ms_06']	 = 'SMTP服务器地址，如:smtp.163.com';
$lang['tpl_ms_07']	 = 'SMTP端口';
$lang['tpl_ms_08']	 = 'SMTP端口,默认为25';
$lang['tpl_ms_09']	 = 'SMTP帐号';
$lang['tpl_ms_10']	 = 'SMTP密码';
$lang['tpl_ms_11']	 = '发送EMAIL';
$lang['tpl_ms_12']	 = '发送EMAIL,如:admin@cscms.com';
$lang['tpl_ms_13']	 = '发送者名称';
$lang['tpl_ms_14']	 = '发送者名称,如:程氏CMS';
$lang['tpl_ms_15']	 = '提交';
$lang['tpl_ms_16']	 = '重置';

//mail_add.html
$lang['tpl_ma_01']	 = '发送类别';
$lang['tpl_ma_02']	 = 'Email单发';
$lang['tpl_ma_03']	 = '指定群发';
$lang['tpl_ma_04']	 = '指定会员组';
$lang['tpl_ma_05']	 = '接收邮箱';
$lang['tpl_ma_06']	 = '接收邮箱，如:admin@chshcms.com';
$lang['tpl_ma_07']	 = '多个邮箱按“回车符号”分隔，一行一个邮箱';
$lang['tpl_ma_08']	 = '会员组';
$lang['tpl_ma_09']	 = '全部';
$lang['tpl_ma_10']	 = '邮件标题';
$lang['tpl_ma_11']	 = '邮件内容';
$lang['tpl_ma_12']	 = '提交';
$lang['tpl_ma_13']	 = '重置';