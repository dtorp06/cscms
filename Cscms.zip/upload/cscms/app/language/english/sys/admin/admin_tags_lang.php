<?php
//控制器
$lang['plub_01']	= '名称不能为空~!';
$lang['plub_02']	= '恭喜您，操作成功~!';
$lang['plub_03']	= '请选择要操作的数据~!';

//视图
$lang['tpl_00']	 = '位置';
$lang['tpl_01']	 = 'TAGS标签管理';
$lang['tpl_02']	 = '选';
$lang['tpl_03']	 = '排序';
$lang['tpl_04']	 = '名称';
$lang['tpl_05']	 = '新增<span class="phide">主标签</span>';
$lang['tpl_06']	 = '人气';
$lang['tpl_07']	 = '操作';
$lang['tpl_08']	 = '确定<span  class="phide">新增</span>';
$lang['tpl_09']	 = '新增<span  class="phide">子标签</span>';
$lang['tpl_10']	 = '删除';
$lang['tpl_11']	 = '全选/反选';
$lang['tpl_12']	 = '修改选中';