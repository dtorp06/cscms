<?php
//控制器
$lang['plub_01'] = '删除项不存在!';

//视图
$lang['tpl_01']  = '位置';
$lang['tpl_02']  = '会员';
$lang['tpl_03']  = '说说管理';
$lang['tpl_04']  = '用户名';
$lang['tpl_05']  = '用户ID';
$lang['tpl_06']  = '查询';
$lang['tpl_07']  = '选';
$lang['tpl_08']  = '发表人';
$lang['tpl_09']  = '内容';
$lang['tpl_10']  = '评论';
$lang['tpl_11']  = '时间';
$lang['tpl_12']  = '操作';
$lang['tpl_13']  = '没有找到相关记录';
$lang['tpl_14']  = '未知UID:';
$lang['tpl_15']  = '删除';
$lang['tpl_16']  = '全选/反选';
$lang['tpl_17']  = '删除选中';