<?php
//控制器
$lang['plub_01'] = '泛域名地址不能为空!';
$lang['plub_02'] = '没有修改权限';
$lang['plub_03'] = '请选择要删除的数据!';

//视图 home.html
$lang['tpl_01']	 = '位置';
$lang['tpl_02']	 = '会员空间';
$lang['tpl_03']	 = '空间配置';
$lang['tpl_04']	 = '泛域名开关';
$lang['tpl_05']	 = '开启';
$lang['tpl_06']	 = '关闭';
$lang['tpl_07']	 = '泛域名地址';
$lang['tpl_08']	 = '域名格式：cscms.com，域名泛解析绑定到网站根目录即可';
$lang['tpl_09']	 = '主页伪静态';
$lang['tpl_10']	 = '地址运行方式';
$lang['tpl_11']	 = '空间人气防刷';
$lang['tpl_12']	 = '域名保留地址';
$lang['tpl_13']	 = '域名保留地址，多个用“|”开隔开';
$lang['tpl_14']	 = '提交';
$lang['tpl_15']	 = '重置';
$lang['tpl_16']	 = '会员ID';
$lang['tpl_17']	 = '会员名称';

//home_pay.html
$lang['tpl_hp_01']	 = '位置';
$lang['tpl_hp_02']	 = '会员空间';
$lang['tpl_hp_03']	 = '模版使用记录';
$lang['tpl_hp_04']	 = '用户名';
$lang['tpl_hp_05']	 = '用户ID';
$lang['tpl_hp_06']	 = '查询';
$lang['tpl_hp_07']	 = '选';
$lang['tpl_hp_08']	 = '模板名称';
$lang['tpl_hp_09']	 = '购买会员';
$lang['tpl_hp_10']	 = '扣除金币';
$lang['tpl_hp_11']	 = '购买时间';
$lang['tpl_hp_12']	 = '操作';
$lang['tpl_hp_13']	 = '没有找到相关记录';
$lang['tpl_hp_14']	 = '未知UID:';
$lang['tpl_hp_15']	 = '删除';
$lang['tpl_hp_16']	 = '全选/反选';
$lang['tpl_hp_17']	 = '删除选中';