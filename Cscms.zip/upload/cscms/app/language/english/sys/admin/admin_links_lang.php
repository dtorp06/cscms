<?php
//控制器
$lang['plub_01']	= '链接标题和地址不能为空！';
$lang['plub_02']	= '链接LOGO不能为空！';
$lang['plub_03']	= '删除项不存在~!';

//view--links.html
$lang['tpl_l_01']	 = '位置';
$lang['tpl_l_02']	 = '首页';
$lang['tpl_l_03']	 = '友情链接';
$lang['tpl_l_04']	 = '标题';
$lang['tpl_l_05']	 = '类型';
$lang['tpl_l_06']	 = '全部';
$lang['tpl_l_07']	 = '文字';
$lang['tpl_l_08']	 = '图片';
$lang['tpl_l_09']	 = '主页显示';
$lang['tpl_l_10']	 = '显示';
$lang['tpl_l_11']	 = '隐藏';
$lang['tpl_l_12']	 = '查询';
$lang['tpl_l_13']	 = '选';
$lang['tpl_l_14']	 = '编号';
$lang['tpl_l_15']	 = 'logo';
$lang['tpl_l_16']	 = '标题';
$lang['tpl_l_17']	 = '链接';
$lang['tpl_l_18']	 = '类型';
$lang['tpl_l_19']	 = '状态';
$lang['tpl_l_20']	 = '操作';
$lang['tpl_l_21']	 = '修改链接';
$lang['tpl_l_22']	 = '修改';
$lang['tpl_l_23']	 = '删除';
$lang['tpl_l_24']	 = '全选/反选';
$lang['tpl_l_25']	 = '删除选中';
$lang['tpl_l_26']	 = '添加新链接';

//view--links_edit.html
$lang['tpl_e_01']	 = '标题';
$lang['tpl_e_02']	 = '请输入链接标题';
$lang['tpl_e_03']	 = '地址';
$lang['tpl_e_04']	 = '请输入链接地址';
$lang['tpl_e_05']	 = '类型';
$lang['tpl_e_06']	 = '文字';
$lang['tpl_e_07']	 = '图片';
$lang['tpl_e_08']	 = '上传图片';
$lang['tpl_e_09']	 = '状态';
$lang['tpl_e_10']	 = '显示';
$lang['tpl_e_11']	 = '隐藏';
$lang['tpl_e_12']	 = '提交';
$lang['tpl_e_13']	 = '重置';
$lang['tpl_e_14']	 = '上传';