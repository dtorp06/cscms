<?php
//controller
$lang['plub_01'] = 'home non static mode, do not need to generate static file ~!';
$lang['plub_02'] = 'directory does not write permission';
$lang['plub_03'] = 'Congratulations, the home page has been generated';
$lang['plub_04'] = 'Congratulations, custom templates have been generated';
//view
$lang['tpl_01'] = 'location';
$lang['tpl_02'] = 'home generated';
$lang['tpl_03'] = 'home site generated';
$lang['tpl_04'] = 'generate computer version';
$lang['tpl_05'] = 'generate mobile version';
$lang['tpl_06'] = 'start generating';
$lang['tpl_07'] = 'custom page generation ';