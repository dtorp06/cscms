<?php
//控制器
$lang['plub_01']	= '参数错误!';

//视图
$lang['tpl_01']	 = '位置';
$lang['tpl_02']	 = '会员';
$lang['tpl_03']	 = '评论管理';
$lang['tpl_04']	 = '用户名';
$lang['tpl_05']	 = '用户ID';
$lang['tpl_06']	 = '数据ID';
$lang['tpl_07']	 = '所属板块';
$lang['tpl_08']	 = '说说';
$lang['tpl_09']	 = '查询';
$lang['tpl_10']	 = '选';
$lang['tpl_11']	 = '发表人';
$lang['tpl_12']	 = '评论内容';
$lang['tpl_13']	 = '板块';
$lang['tpl_14']	 = '数据标题';
$lang['tpl_15']	 = '时间';
$lang['tpl_16']	 = '操作';
$lang['tpl_17']	 = '没有找到相关记录';
$lang['tpl_18']	 = '游客';
$lang['tpl_19']	 = '未知UID:';
$lang['tpl_20']	 = '删除';
$lang['tpl_21']	 = '全选/反选';
$lang['tpl_22']	 = '删除选中';