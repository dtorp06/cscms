<?php
//控制器
$lang['plub_01']	= '未指定数据表~!';
$lang['plub_02']	= '抱歉，表优化失败';
$lang['plub_03']	= '恭喜你，优化成功';
$lang['plub_04']	= '抱歉，修复表失败';
$lang['plub_05']	= '恭喜你，数据表修复成功';
$lang['plub_06']	= '尚未选中数据表~!';
$lang['plub_07']	= '恭喜你，备份成功';
$lang['plub_08']	= '抱歉，备份失败~!';
$lang['plub_09']	= '尚未选中任何数据~!';
$lang['plub_10']	= '恭喜你，还原成功';
$lang['plub_11']	= '尚未选中任何文件~!';
$lang['plub_12']	= '恭喜你，删除成功';


//view--basedb.html
$lang['tpl_01'] 	= '位置';
$lang['tpl_02'] 	= '系统';
$lang['tpl_03'] 	= '备份还原';
$lang['tpl_04'] 	= '数据库备份';
$lang['tpl_05'] 	= '数据库还原';
$lang['tpl_06'] 	= '选';
$lang['tpl_07'] 	= '表名';
$lang['tpl_08'] 	= '类型';
$lang['tpl_09'] 	= '编码';
$lang['tpl_10'] 	= '记录数';
$lang['tpl_11'] 	= '使用空间';
$lang['tpl_12'] 	= '碎片';
$lang['tpl_13'] 	= '操作';
$lang['tpl_14'] 	= '优化';
$lang['tpl_15'] 	= '修复';
$lang['tpl_16'] 	= '结构';
$lang['tpl_17'] 	= '全选/反选';
$lang['tpl_18'] 	= '优化选中';
$lang['tpl_19'] 	= '修复选中';
$lang['tpl_20'] 	= '开始备份';

$lang['tpl_hy_01'] 	= '位置';
$lang['tpl_hy_02'] 	= '系统';
$lang['tpl_hy_03'] 	= '备份还原';
$lang['tpl_hy_04'] 	= '数据库备份';
$lang['tpl_hy_05'] 	= '数据库还原';
$lang['tpl_hy_06'] 	= '选';
$lang['tpl_hy_07'] 	= '文件名';
$lang['tpl_hy_08'] 	= '文件大小';
$lang['tpl_hy_09'] 	= '备份时间';
$lang['tpl_hy_10'] 	= '卷数量';
$lang['tpl_hy_11'] 	= '操作';
$lang['tpl_hy_12'] 	= '下载';
$lang['tpl_hy_13'] 	= '删除';
$lang['tpl_hy_14'] 	= '还原';
$lang['tpl_hy_15'] 	= '暂无数据记录';
$lang['tpl_hy_16'] 	= '全选/反选';
$lang['tpl_hy_17'] 	= '删除选中';