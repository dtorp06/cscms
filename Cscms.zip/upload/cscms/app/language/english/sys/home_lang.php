<?php
$lang['home_01'] = 'sorry, the member does not save ~!';
$lang['home_02'] = 'sorry, member ID format wrong ~!';
//ajax
$lang['ajax_01'] = 'page does not exist';
$lang['ajax_02'] = 'remind you';
$lang['ajax_03'] = 'parameter error';
$lang['ajax_04'] = 'logon timeout';
$lang['ajax_05'] = 'can\'t praise yourself';
$lang['ajax_06'] = 'member does not exist';
$lang['ajax_07'] = 'youve got a TA today';
$lang['ajax_08'] = 'cannot focus on yourself';
$lang['ajax_09'] = 'songs do not exist';
$lang['ajax_10'] = 'collection of songs';
$lang['ajax_11'] = '%s pays attention to you and becomes your fan';
$lang['ajax_12'] = '%s just gave you a hand';
$lang['ajax_13'] = 'system message';
//fans
$lang['fans_01'] = 'fans';
//feed
$lang['feed_01'] = 'recent situation';
//friend
$lang['friend_01'] = 'concern buddy';
//funco
$lang['funco_01'] = 'visitor';
//gbook
$lang['gbook_01'] = 'message';
$lang['gbook_02'] = 'reply';
$lang['gbook_03'] = 'system message';
$lang['gbook_04'] = 'just%s on your home page, leave a message for you';
$lang['gbook_05'] = 'argument error';
$lang['gbook_06'] = 'illegal submission of data';
$lang['gbook_07'] = 'rest, no watering! ';
$lang['gbook_08'] = 'the content cannot be empty! ';
$lang['gbook_09'] = 'you are not logged in, please login first! ';
$lang['gbook_10'] = 'sorry, message failed, try again later! ';
$lang['gbook_11'] ='ID cannot be empty!';
$lang['gbook_12'] = 'illegal operation';
$lang['gbook_13'] = 'login timeout';
$lang['gbook_14'] = 'data does not exist! ';
$lang['gbook_15'] = 'you do not have permission to delete messages from others! ';
//index
$lang['index_01'] = 'personal homepage';
//info
$lang['info_01'] = 'personal data';