<?php
//global controller
$lang['p_01'] = 'the page you visited does not exist';
$lang['p_02'] = 'remind you ~!';
//uc.php
$lang['p_03'] ='UC synchronization has been turned off';
$lang['p_04'] = 'authorization has expired';
$lang['p_05'] = 'illegal request';
//ulog.php
$lang['p_06'] = 'account cannot be empty';
$lang['p_07'] = 'password cannot be empty';
$lang['p_08'] = 'register activation mail';
$lang['p_09'] = 'your account is not activated, please go to the mailbox to activate';
$lang['p_10'] = 'your account does not exist';
$lang['p_11'] = 'your password is wrong';
$lang['p_12'] = 'your account number is locked';
$lang['p_13'] = 'your account is audited';
//gbook.php
$lang['p_14'] = 'webmaster has closed message!';
$lang['p_15'] = 'illegal submission of data';
$lang['p_16'] = 'the content cannot be empty!';
$lang['p_17'] = 'sorry, message failed, try again later';
$lang['p_18'] = 'rest under, leave message';