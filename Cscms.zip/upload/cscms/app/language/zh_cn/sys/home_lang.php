<?php
$lang['home_01']  = '抱歉，该会员不存~!';
$lang['home_02']  = '抱歉，会员ID格式错误~!';
//ajax
$lang['ajax_01']  = '页面不存在';
$lang['ajax_02']  = '提醒您';
$lang['ajax_03']  = '参数错误';
$lang['ajax_04']  = '登录超时';
$lang['ajax_05']  = '不能赞自己';
$lang['ajax_06']  = '会员不存在';
$lang['ajax_07']  = '你今天已经赞过TA了';
$lang['ajax_08']  = '不能关注自己';
$lang['ajax_09']  = '歌曲不存在';
$lang['ajax_10']  = '收藏了歌曲';
$lang['ajax_11']  = '%s关注了你，成为了你的粉丝';
$lang['ajax_12']  = '%s刚刚赞了你一下';
$lang['ajax_13']  = '系统消息';
//fans
$lang['fans_01']  = '的粉丝';
//feed
$lang['feed_01']  = '的近况';
//friend
$lang['friend_01']  = '的关注好友';
//funco
$lang['funco_01']  = '的访客';
//gbook
$lang['gbook_01']  = '的留言';
$lang['gbook_02']  = '回复';
$lang['gbook_03']  = '系统消息';
$lang['gbook_04']  = '刚刚%s在你的主页给你留言了';
$lang['gbook_05']  = '参数错误！';
$lang['gbook_06']  = '非法提交数据！';
$lang['gbook_07']  = '休息下，别灌水！';
$lang['gbook_08']  = '内容不能为空！';
$lang['gbook_09']  = '您还没有登录，请先登录！';
$lang['gbook_10']  = '对不起，留言失败，稍后再试！';
$lang['gbook_11']  = 'ID不能为空！';
$lang['gbook_12']  = '非法操作！';
$lang['gbook_13']  = '登陆超时！';
$lang['gbook_14']  = '数据不存在！';
$lang['gbook_15']  = '您没有权限删除别人的留言！';
//index
$lang['index_01']  = '的个人主页';
//info
$lang['info_01']  = '的个人资料';
