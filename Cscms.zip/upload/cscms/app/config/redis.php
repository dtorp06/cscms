<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Redis缓存配置
$config = require CSCMS.'sys'.FGF.'CS_Redis.php';
